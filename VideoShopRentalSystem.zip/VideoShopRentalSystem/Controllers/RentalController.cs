﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VideoShopRentalSystem.Data;
using VideoShopRentalSystem.Models;


public class RentalController : Controller
{
    private readonly ApplicationDbContext _db;


    public RentalController(ApplicationDbContext db)
    {
        _db = db;
    }


    // Select customer, show movie list
    public IActionResult Create()
    {
        ViewBag.Customers = _db.Customers.ToList();
        ViewBag.Movies = _db.Movies.Where(m => m.IsAvailable).ToList();
        return View();
    }


    // Save rental header & detail
    [HttpPost]
    public IActionResult Create(int customerId, int[] movieIds)
    {
        var header = new RentalHeader
        {
            CustomerId = customerId
        };


        _db.RentalHeaders.Add(header);
        _db.SaveChanges();


        foreach (var movieId in movieIds)
        {
            var detail = new RentalDetail
            {
                RentalHeaderId = header.Id,
                MovieId = movieId
            };


            _db.RentalDetails.Add(detail);


            var movie = _db.Movies.Find(movieId);
            movie.IsAvailable = false;
        }


        _db.SaveChanges();
        return RedirectToAction("Index");
    }


    // List rentals
    public IActionResult Index()
    {
        var rentals = _db.RentalHeaders
            .Include(r => r.Customer)
            .Include(r => r.RentalDetails)
            .ThenInclude(d => d.Movie)
            .ToList();


        return View(rentals);
    }


    // Return movies
    public IActionResult Return(int id)
    {
        var rental = _db.RentalHeaders
            .Include(r => r.RentalDetails)
            .ThenInclude(d => d.Movie)
            .FirstOrDefault(r => r.Id == id);


        return View(rental);
    }


    [HttpPost]
    public IActionResult ReturnMovies(int[] detailIds)
    {
        foreach (var dId in detailIds)
        {
            var detail = _db.RentalDetails.Find(dId);
            detail.Returned = true;


            var movie = _db.Movies.Find(detail.MovieId);
            movie.IsAvailable = true;
        }


        _db.SaveChanges();
        return RedirectToAction("Index");
    }
}

