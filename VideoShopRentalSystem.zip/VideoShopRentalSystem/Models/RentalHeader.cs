﻿namespace VideoShopRentalSystem.Models
{
    using System;
    using System.Collections.Generic;
    public class RentalHeader
    {
        public int Id { get; set; }
        public int CustomerId {  get; set; }
        public DateTime RentalDate { get; set; } = DateTime.Now;
        public bool IsReturned {  get; set; } = false;
        public Customer? Customer { get; set; }
        public List<RentalDetail>? RentalDetails { get; set; }
    }
}
