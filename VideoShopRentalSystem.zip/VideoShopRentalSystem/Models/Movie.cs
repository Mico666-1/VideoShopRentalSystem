﻿namespace VideoShopRentalSystem.Models
{
    using System.ComponentModel.DataAnnotations;
    public class Movie
    {
        public int Id { get; set; }
        required
        public string Title { get; set; }
        public bool IsAvailable { get; set; } = true;
    }
}
