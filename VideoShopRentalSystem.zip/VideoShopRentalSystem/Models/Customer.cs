﻿namespace VideoShopRentalSystem.Models
{
    using System.ComponentModel.DataAnnotations;
    public class Customer
    {
        public int Id { get; set; }
        required
        public string FirstName {  get; set; }
        required
        public string LastName { get; set; }
        required
        public string Address {  get; set; }
    }
}
