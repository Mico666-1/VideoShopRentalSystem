﻿namespace VideoShopRentalSystem.Models
{
    public class RentalDetail
    {
        public int Id { get; set; }
        public int RentalHeaderId {  get; set; }
        public RentalHeader? RentalHeader { get; set; }
        public int MovieId {  get; set; }
        public Movie? Movie { get; set; }
        public bool Returned {  get; set; } = false;
    }
}
